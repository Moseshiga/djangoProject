from django.shortcuts import render
from django.http import HttpResponse
from .forms import *
import commands


# Create your views here.

def index(request):
    if request.method == "POST":
        form = tasksForm(request.POST)
        lang = request.POST.get("lang")
        code = request.POST.get("code")
        pass
        print("Lang: ", lang)
        print("Code: ", code)
        file = open('tasks/code.cpp', 'w')
        file.write(code)
        file = open('tasks/code.cpp')
        print(file.read())
        status, res = commands.getstatusoutput("tasks/a.exe")
    return render(request, 'tasks/index.html', {'title': 'tasks'})


