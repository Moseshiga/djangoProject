from django import forms


class tasksForm(forms.Form):
    solution = forms.Textarea
    lang = forms.ModelChoiceField